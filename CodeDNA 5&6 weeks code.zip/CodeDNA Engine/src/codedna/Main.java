package codedna;

import java.io.File;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws Exception {

        printBanner();

        // ── Resolve input file ─────────────────────────────────
        String inputFile;

        if (args.length > 0) {
            inputFile = args[0];
        } else {
            Scanner sc = new Scanner(System.in);
            System.out.println("\n  Enter the path to your .java file:");
            System.out.print("  > ");
            inputFile = sc.nextLine().trim();

            if (inputFile.isEmpty()) {
                inputFile = "sample/FirstDemo.java";
                System.out.println("  Using default: " + inputFile);
            }
        }

        File f = new File(inputFile);
        if (!f.exists()) {
            System.out.println("\n  ❌ File not found: " + inputFile);
            return;
        }

        System.out.println("\n  🔬 Scanning DNA of: " + f.getName());

        // ── Step 1: Parse (Week 4 + 5) ──────────────────────────
        System.out.print("  ▸ Parsing AST...");
        ASTParser.CodeMetrics metrics = ASTParser.parse(inputFile);
        System.out.println(" ✔");

        System.out.println();
        System.out.println("  ===== CodeDNA Parser Results =====");
        System.out.println("  File            : " + metrics.fileName);
        System.out.println("  Total Lines     : " + metrics.totalLines);
        System.out.println("  Code Lines      : " + metrics.codeLines);
        System.out.println("  Comment Lines   : " + metrics.commentLines);
        System.out.println("  Blank Lines     : " + metrics.blankLines);
        System.out.println("  Classes         : " + metrics.classCount + " " + metrics.classNames);
        System.out.println("  Methods         : " + metrics.methodCount + " " + metrics.methodNames);
        System.out.println("  Loops           : " + metrics.loopCount);
        System.out.println("  Nested Loops    : " + metrics.nestedLoopCount);
        System.out.println("  If Statements   : " + metrics.ifCount);
        System.out.println("  Try/Catch       : " + metrics.tryCount);
        System.out.println("  Imports         : " + metrics.importCount);
        System.out.println("  Complexity Score: " + metrics.complexityScore + "/100");
        System.out.println("  Health Score    : " + metrics.healthScore + "/100");
        System.out.println("  Top Keywords    : " + metrics.keywords);
        System.out.println("  ===================================");

        // ── Step 2: Generate creature (Week 6) ──────────────────
        System.out.print("\n  ▸ Generating organism...");
        CreatureGenerator.Creature creature = CreatureGenerator.generate(metrics);
        System.out.println(" ✔  [" + creature.personality + "]");
        System.out.println();
        System.out.println(creature); // uses Creature.toString()

        System.out.println("  (SVG rendering and HTML export are not implemented yet — Week 7+)");
    }

    private static void printBanner() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════════╗");
        System.out.println("  ║   ██████╗ ██████╗ ██████╗ ███████╗          ║");
        System.out.println("  ║  ██╔════╝██╔═══██╗██╔══██╗██╔════╝          ║");
        System.out.println("  ║  ██║     ██║   ██║██║  ██║█████╗            ║");
        System.out.println("  ║  ██║     ██║   ██║██║  ██║██╔══╝            ║");
        System.out.println("  ║  ╚██████╗╚██████╔╝██████╔╝███████╗          ║");
        System.out.println("  ║   ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝         ║");
        System.out.println("  ║         DNA  ──  Biomorphic Code Visualizer ║");
        System.out.println("  ╚══════════════════════════════════════════════╝");
        System.out.println("  Pure Java · Zero external libraries · JDK 17+  ");
        System.out.println();
    }
}
